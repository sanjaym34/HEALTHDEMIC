const Joi = require('joi');

module.exports.patientSchema = Joi.object({
    campground: Joi.object({
        name : Joi.string().required(),
        number : Joi.string().required(),
        address : Joi.string().required(),
        prevMedicalCondition : Joi.string().required(),
        Age : Joi.number().required(0)
    }).required()
});
    