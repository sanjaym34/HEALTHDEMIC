const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const PatientSchema = new Schema({
    name : String,
    username : String,
    number : String,
    number2: String,
    address : String,
    cityAndState: String,
    pinCode: String,
    gender: String,
    bloodroup: String,
    healthInsurance: String,
    allergies: String,
    prev : String,
    Age : Number
})

module.exports = mongoose.model('Patient', PatientSchema);