const express = require('express');
const path = require('path');
const mongoose = require('mongoose');
const ejsMate = require('ejs-mate');
const { patientSchema } = require('./schemasvalidation');
const methodOverride = require('method-override');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const cookie = require('cookie-parser');
const session = require('express-session');
const flash = require('flash');
const patient = require('./models/patient');

mongoose.connect('mongodb://localhost:27017/healthdemic', {
    useNewUrlParser: true,
    useCreateIndex: true,
    useUnifiedTopology: true
});

const db = mongoose.connection;
db.on("error", console.error.bind(console, "connection error:"));
db.once("open", () => {
    console.log("Database connected");
});

const app = express();

app.engine('ejs', ejsMate);
app.set('view engine', 'ejs');
app.use(express.static(path.join(__dirname, '/public')));
app.set('views', path.join(__dirname, 'views'));

app.use(express.urlencoded({ extended: true }));
app.use(methodOverride('_method'));
app.use(cookie());

async function verify(req, res, next) {
    console.log(req.cookies);
    const token = await req.cookies.token;
    if (!token) {
        req.auth = "Not allowed";
        next();
    }
    else {
        try {
            const decode = await jwt.verify(token, "mysecretKEY", { algorithm: 'HS256' })
            req.dataa = decode;
            req.auth = "allowed"
            next();
        }
        catch (e) {
            console.log(e.message);
            req.auth = "Not allowed";
            next();
        }

    }
}

app.get('/signup', (req, res) => {
    res.render('signup');
    console.log('GET /signup i.e. SIGNUP');
})

app.post('/signup', async (req, res) => {
    console.log("POST /signup i.e. SIGNUP");

    var newPatient = new patient({
        name: req.body.name,
        number: req.body.number,
    })
    if (req.body.number.length < 10) {
        req.flash("error", "Phone number should have 10 digits");
        res.redirect('/signup');
    } else {
        try {
            const salt = await bcrypt.genSalt(10);
            let number = await bcrypt.hash(req.body.number, salt);
            newPatient.number = number;
            await newPatient.save();
            console.log(newPatient);
            res.redirect('/dash');
        }
        catch (e) {
            console.log(e);
        }
    }
})

app.get('/login', (req, res) => {
    console.log("GET: /login");
    res.render('login');
})

app.post('/login', async (req, res) => {
    try {
        const { name, number } = req.body;
        console.log(number);
        const pat = await patient.findOne({ name });
        console.log(pat)
        if (!pat) {
            res.json({ message: "Invalid Creds" });
        }
        const value = await bcrypt.compare(number, pat.number);
        const payload = {
            id: pat._id
        }
        if (value) {
            const token = await jwt.sign(payload, "mysecretKEY", { algorithm: 'HS256' });
            res.cookie("token", token, { httpOnly: true });
            console.log('POST: /login')
            res.redirect("/home");
        }
        else {
            res.json({ message: "Invalid Creds" })
        }
    }
    catch (e) {
        console.log(e);
    }
})

app.get("/logout", (req, res) => {
    res.clearCookie("token");
    res.redirect("/login");
});

app.get('/dash', verify, async (req, res) => {

    if (req.auth == "Not allowed" || !req.auth) {
        res.redirect("/login");
        return;
    } else {
        var patientID = req.dataa.id;
        console.log(patientID);
        console.log("GET: /DASH");
        try {
            const foundPatient = await patient.findById(patientID);
            console.log(foundPatient);
            res.render('dash', { foundPatient: foundPatient });
        }
        catch (e) {
            console.log(e);
        }

    }
})

app.post('/dash', verify, async (req, res) => {
    const patientID = req.dataa.id;
    var foundPatient = await patient.findById(patientID);
    foundPatient.age = req.body.age;
    foundPatient.gender = req.body.gender;
    foundPatient.address = req.body.address;
    foundPatient.cityAndState = req.body.cityAndState;
    foundPatient.pinCode = req.body.pinCode;
    foundPatient.bloodGroup = req.body.bloodGroup;
    foundPatient.allergies = req.body.allergies;
    foundPatient.prev = req.body.prev;
    foundPatient.healthInsurance = req.body.healthInsurance;
    await foundPatient.save()
    console.log(foundPatient);
    res.redirect('/home');
})

app.get('/home', verify, (req, res) => {
    console.log('Get:/ Home');
    res.render('home');
})

app.get('/profile', verify, async (req, res) => {
    console.log('GET: /Profile');
    const patientID = req.dataa.id;

    var foundPatient = await patient.findById(patientID);
    res.render('profile', { foundPatient: foundPatient });
})

app.get('/videos', verify, (req, res) => {
    console.log('GET: /videos');
    res.render('videos');
})

app.get('/videocall', verify, (req, res) => {
    console.log('Get:/ video call');
    res.render('videocall');
})

/*app.all('*', (req, res, next) => {
    next(new ExpressError('Page Not Found', 404));
})

app.use((err, req, res, next) => {
    const { statusCode = 500 } = err;
    if (!err.message) err.message = 'Oh No!!! SOmething went wrong'
    res.status(statusCode).render('error', { err });
})*/

app.listen(3000, () => {
    console.log("Server working on PORT 3000!!!");
})